package com.example.myapplication;

import android.app.Activity;

public class activity_create_queue extends Activity {
}
