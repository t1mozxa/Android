import android.R
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Color

class MainActivity : AppCompatActivity() {

    var createQueueButton: Button? = null
    var joinQueueButton: Button? = null
    var queueNameTextView: TextView? = null
    var userListTextView: TextView? = null
    var menuButton: ImageButton? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val view = findViewById<View>(R.id.myView)
        val linearGradient = LinearGradient(
            0f, 0f, view.width.toFloat(), view.height.toFloat(),
            Color.parseColor("#BA83FF"), Color.WHITE,
            Shader.TileMode.CLAMP
        )
        val shader = Shader.newInstance(linearGradient)
        view.paint.shader = shader
        createQueueButton = findViewById<Button>(R.id.createQueueButton)
        joinQueueButton = findViewById<Button>(R.id.joinQueueButton)
        queueNameTextView = findViewById<TextView>(R.id.queueNameTextView)
        userListTextView = findViewById<TextView>(R.id.userListTextView)
        menuButton = findViewById<ImageButton>(R.id.menuButton)
        createQueueButton.setOnClickListener(View.OnClickListener {
            // Запустить активность создания очереди
        })
        joinQueueButton.setOnClickListener(View.OnClickListener {
            // Запустить активность присоединения к очереди
        })
        menuButton.setOnClickListener(View.OnClickListener {
            // Отобразить меню настроек
        })
    } // Другие методы для управления очередью и пользователями
}