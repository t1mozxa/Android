import android.R
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class CreateQueueActivity : AppCompatActivity() {
    var queueNameEditText: EditText? = null
    var createButton: Button? = null
    var linkTextView: TextView? = null
    var qrCodeTextView: TextView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_queue)
        queueNameEditText = findViewById<EditText>(R.id.queue_name_edit_text)
        createButton = findViewById<Button>(R.id.create_button)
        linkTextView = findViewById<TextView>(R.id.link_text_view)
        qrCodeTextView = findViewById<TextView>(R.id.qr_code_text_view)
        createButton.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {
                val queueName = queueNameEditText.getText().toString()
                if (queueName.isEmpty()) {
                    Toast.makeText(this, "Введите название очереди", Toast.LENGTH_SHORT).show()
                    return
                }
                // Создать очередь на сервере и получить ссылку и QR-код
                val link = "https://example.com/join/$queueName"
                val qrCode = "qrcode://example.com/join/$queueName"
                linkTextView.setText(link)
                qrCodeTextView.setText(qrCode)
            }
        })
    }
}